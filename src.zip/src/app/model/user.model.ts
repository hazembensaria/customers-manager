export class User{
    mail! : string;
    password!:string ;
    role!:string
}